/*
 * File:   ecu1_main.c
 * Group : 03
 * Members: ALEENA MARIA GEORGE
 *          LAXMIKANT
 *          S SAMEEKSHA 
 *
 * Created on 10 May, 2025, 12:40 PM
 */




#include <xc.h>
#include "ecu1_sensor.h"
#define _XTAL_FREQ 20000000
uint16_t get_speed()
{
    __delay_us(10);
    uint16_t adc_reg_val = read_adc(SPEED_ADC_CHANNEL);
    return (adc_reg_val / 10.33);
}

unsigned char get_gear_pos()
{
    static unsigned char gear_pos;
    char key = read_switches(STATE_CHANGE);
    if(key == GEAR_UP)
    {
        if(gear_pos < MAX_GEAR)
            gear_pos++;
    }
    else if(key == GEAR_DOWN)
    {
        if(gear_pos > 1)
            gear_pos--;
    }
    else if(key == COLLISION)
	    gear_pos = 9;

    return gear_pos;
}

uint16_t get_engine_temp()
{
    __delay_us(10);
    uint16_t adc_reg_val = read_adc(ENG_TEMP_ADC_CHANNEL);
    return (((adc_reg_val * ((float)5 / 1023)) * 100));
}

static void init_config()
{
    init_can();
    init_adc();
    init_matrix_keypad();
}
void main()
{
    init_config(); 
    unsigned char gear_pos = 0;
    while(1)
    {
        
        //Have to get speed and transmit to ECU3
        uint16_t speed = get_speed();
        uint8_t speed_buff[] = {((speed/10) + '0'), ((speed % 10) + '0'), '\0'};
        can_transmit(SPEED_MSG_ID, speed_buff, 2); 
        while(TXB0REQ);                                                         // This is used to for delay 
    
        //Have to get gear position and transmit to ECU3
        gear_pos = get_gear_pos();
        uint8_t gear_buff[] = {(gear_pos + '0'), '\0'};
        can_transmit(GEAR_MSG_ID, gear_buff, 1);
        while(TXB0REQ);

        // Have to get the engine temp and transmit to ECU3 (Dashboard) 
        uint16_t engine_temp = get_engine_temp();
        const uint8_t engine_temp_buff[] = {((engine_temp/10) + '0'), ((engine_temp % 10) + '0'), '^', 'c', '\0'};
        can_transmit(ENG_TEMP_MSG_ID, engine_temp_buff, 4);
        while(TXB0REQ);
        
    }
}	

