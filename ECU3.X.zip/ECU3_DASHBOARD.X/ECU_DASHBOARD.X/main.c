/*
 * File:   ecu3_main.c
 * Group : 03
 * Members: ALEENA MARIA GEORGE
 *          LAXMIKANT
 *          S SAMEEKSHA 
 *
 * Created on 25 May, 2025, 10:40 AM
 */





#include <xc.h>
#include "DASHBOARD.h"

#define _XTAL_FREQ 20000000

static void init_config()
{
    init_can();
    init_clcd();
    TRISB0 = TRISB1 = 0;
    TRISB6 = TRISB7 = 0;
    RB0 = RB1 = RB6 = RB7 = 0;
    
    
}
void main()
{
    init_config();                                                              //Configuring the pheripherals
    clcd_print("SP G TMP  RPM  I", LINE1(0));
    uint8_t speed = 0, gear_pos = 0, engine_temp = 0;
    uint8_t  rx_data[8];
    char buff[8];
    while(1)
    {
        uint16_t rx_id;
        uint8_t  rx_len = sizeof(rx_data);
        clcd_putch(' ', LINE2(9));
        if (can_receive(&rx_id, rx_data, &rx_len )) 
        {     
            
            switch (rx_id)
            { 
                case SPEED_MSG_ID:
                    rx_data[2] = '\0';                                          // null-terminate
                   clcd_print(rx_data, LINE2(0));
                    break;

                case GEAR_MSG_ID:    
                {
                    char temp = rx_data[0];

                   switch(temp)
                    {
                        case '1': clcd_print("N", LINE2(3)); break;
                        case '2': clcd_print("1", LINE2(3)); break;
                        case '3': clcd_print("2", LINE2(3)); break;
                        case '4': clcd_print("3", LINE2(3)); break;
                        case '5': clcd_print("4", LINE2(3)); break;
                        case '6': clcd_print("5", LINE2(3)); break;
                        case '7': clcd_print("6", LINE2(3)); break;                       
                       case '8': clcd_print("R", LINE2(3)); break;
                       case '9': clcd_print("C ", LINE2(3)); break;
                   }
                }
                    break;
                    
                case ENG_TEMP_MSG_ID:
                    rx_data[rx_len] = '\0';                                     // ensure termination
                   clcd_print(rx_data, LINE2(5));
                    break;
                    
                 case RPM_MSG_ID:
                    rx_data[rx_len] = '\0';                                     // null-terminate
                    clcd_print(rx_data, LINE2(10));
                    break;
                    
                    
                 case INDICATOR_MSG_ID:
                     
                    rx_data[rx_len] = '\0';                                     // null-terminate
                    clcd_print(rx_data, LINE2(15));
                    if(strcmp(rx_data, "L") == 0)
                    {
                        RB6 = RB7 = 1;
                        RB0 = RB1 = 0;
                    }
                    else if(strcmp(rx_data, "R") == 0)
                    {
                        RB6 = RB7 = 0;
                        RB0 = RB1 = 1;
                    }
                    else
                    {
                        RB6 = RB7 = RB0 = RB1 = 0;
                    }                   
                    break;
            }
        }

        __delay_ms(100);                                                        // Small delay
    }
}

	





