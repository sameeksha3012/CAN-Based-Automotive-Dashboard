
#ifndef MSG_ID_H
#define	MSG_ID_H



#define SPEED_MSG_ID 0x11
#define GEAR_MSG_ID 0x22
#define RPM_MSG_ID 0x3
#define ENG_TEMP_MSG_ID 0x01
#define INDICATOR_MSG_ID 0x02

#endif	/* MSG_ID_H */




