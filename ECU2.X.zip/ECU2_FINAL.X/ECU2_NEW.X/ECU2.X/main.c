/*
 * File:   ecu2_main.c
 * Group : 03
 * Members: ALEENA MARIA GEORGE
 *          LAXMIKANT
 *          S SAMEEKSHA 
 *
 * Created on 25 May, 2025, 10:00 AM
 */






#include <xc.h>
#include "ECU2.h"

uint16_t get_rpm()
{
    unsigned short adc_value = read_adc(RPM_ADC_CHANNEL);
    uint16_t rpm_value = 1500 + ((uint32_t)adc_value * 5500) / 1023;

    return rpm_value;
}
unsigned char  prev =  e_ind_off;
IndicatorStatus process_indicator()
{
    // Read the keypad input
    if(RC0 == 0)
    {
        prev = 1;
        return 1;
    }
    else if(RC1==0)
    {
        prev = 2;
        return 2;
    }else if(RC2 ==0)
    {
        prev = 3;
        return 3;
    }
    return prev;
}
static void init_config()
{
    init_can();
    init_adc();
    init_keypad();
}
void main()
{
   init_config();
   uint16_t rpm = 0;
   

    while (1)
    {
        // Get RPM value
        rpm = get_rpm();
        char rpm_str[6];
        sprintf(rpm_str,"%4u",rpm);
        can_transmit(RPM_MSG_ID, rpm_str,4);
        while(TXB0REQ);
        // Process indicator status
        int ind = process_indicator();
        switch (ind)
        {
            case 1:
            {
                char buff1[] = "L";
                can_transmit(INDICATOR_MSG_ID, buff1, 1);
                while(TXB0REQ);
                break;
            }
            case 2:
            {
                char buff2[] = "R";
                can_transmit(INDICATOR_MSG_ID, buff2, 1);
                while(TXB0REQ);
                break;
            }
            case 3:
            {
                char buff3[] = "O";
                can_transmit(INDICATOR_MSG_ID, buff3, 1);
                while(TXB0REQ);
                break;
            }
        }

        
    }
   
}
	
