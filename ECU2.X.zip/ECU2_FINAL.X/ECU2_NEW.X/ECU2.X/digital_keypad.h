
#ifndef DIGITAL_KEYPAD_H
#define	DIGITAL_KEYPAD_H

#define EDGE 1
#define LEVEL 0
#define KEY_PORT PORTC
#define KEY_PORT_DDR TRISC
#define sw1 0x0e
#define sw2 0x0d
#define sw3 0x0b
#define sw4 0x07
#define ALL_RELEASED 0x0f
void init_keypad();
unsigned char read_switch(char);

#endif	/* DIGITAL_KEYPAD_H */

