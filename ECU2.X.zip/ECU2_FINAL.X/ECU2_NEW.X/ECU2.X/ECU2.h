
#ifndef ECU2_H
#define	ECU2_H

#include <stdint.h>
#include "digital_keypad.h"
#include "adc1.h"
#include <stdio.h>
#include "can.h"
#include <stdint.h>
#include "clcd.h"
#include "msg_id.h"
#define _XTAL_FREQ 20000000

#define RPM_ADC_CHANNEL 0x04

#define LED_OFF 0
#define LED_ON 1

#define RIGHT_IND_ON() (PORTB = PORTB | 0xC0)
#define RIGHT_IND_OFF() (PORTB = PORTB & ~0xC0)
#define LEFT_IND_ON() (PORTB = PORTB | 0x03)
#define LEFT_IND_OFF() (PORTB = PORTB & ~0x03)

typedef enum {
    e_ind_off,
    e_ind_left,
    e_ind_right
} IndicatorStatus;

extern volatile IndicatorStatus prev_ind_status, cur_ind_status;
extern volatile unsigned char led_state;

uint16_t get_rpm();
IndicatorStatus process_indicator();


#endif	/* ECU2_H */

