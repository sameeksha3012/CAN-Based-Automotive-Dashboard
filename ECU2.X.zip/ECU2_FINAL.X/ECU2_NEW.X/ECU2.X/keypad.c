#include <xc.h>
#include "ECU2.h"

void init_keypad()
{
    TRISC = TRISC | 0X0F;
}

unsigned char read_switch(char detection_type)
{
    char flag = 1;
    if(detection_type == EDGE)
    {
        if((KEY_PORT & ALL_RELEASED) != ALL_RELEASED && flag)
        {
            //return (KEY_PORT & ALL_RELEASED) ;
            flag = 0;
            return (KEY_PORT & ALL_RELEASED) ; 
        }
        else if(KEY_PORT == 0x0f)
            flag = 1;
    }
    else if(detection_type == LEVEL)
        return KEY_PORT & ALL_RELEASED ;
    return ALL_RELEASED;
}